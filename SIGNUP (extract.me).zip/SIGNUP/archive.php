<?php
$conn = new mysqli('localhost', 'root', '', 'user_system');

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Read archived user's data
$result = $conn->query('SELECT * FROM users WHERE status="archived"');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archived Users</title>
</head>
<body>
    <h2>Archived Users</h2>
    <table border="1">
        <tr>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <th>Age</th>
            <th>Birthday</th>
            <th>Address</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['first_name']; ?></td>
                <td><?php echo $row['middle_name']; ?></td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['age']; ?></td>
                <td><?php echo $row['birthday']; ?></td>
                <td><?php echo $row['address']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    <a href="index.php">Back to User Management</a>
</body>
</html>

<?php
$conn->close();
?>