<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Sign Up</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background: url('2.png') no-repeat center center fixed;
    background-size: cover;
    margin: 50;
    padding: 50;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    
}
        header {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            color: #000957;
            padding: 10px 20px;
            width: 100%;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 10;
            border-bottom: 1px solid #ddd;
        }

        header .logo {s
            display: flex;
            align-items: center;
            margin-right: 10px;
        }

        header  .logo img {
        width: 120px; /* Adjust this value to make the logo larger */
        height: auto; /* Keeps the aspect ratio of the logo */
        margin-right: 15px; /* Space between the logo and the text */
    }
        .header-text {
        display: flex;
        flex-direction: column;
        align-items: center; /* Centers the text horizontally */
        text-align: center; /* Ensures multi-line text is also centered */
    }

    .header-text h1 {
        margin: 0;
        font-size: 24px;
        color: #000957; /* Blue color for the text */
    }

    .header-text h2 {
        margin: 5px 0 0; /* Adds a small margin between title and address */
        font-size: 16px;
        color: #555; /* Subtle color for the address */
    }

    .form-container {
    background: #FFEB00    ;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 350px;
    text-align: center;
    margin-top: 170px; /* Adjusted margin-top to move the form lower */
}

        .form-container h2 {
            color: #000957;
            margin-bottom: 20px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        .form-container input {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container button {
            padding: 10px;
            background: #000957;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-container button:hover {
            background: #0056b3;
        }

        .form-container a {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .alternate {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">
        <img src="logogogo.png" alt="Logo">
    </div>
    <div class="header-text">
        <h1>ST. JOHN PAUL II COLLEGE OF DAVAO</h1>
        <h2>Ecoland Drive, Matina, Davao City</h2>
    </div>
</header>
    <div class="form-container" id="login-form">
        <h2>Welcome Back</h2>
        <p>Enter your credentials to login</p>
        <form action="login.php" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="alternate">
            <a href="#" onclick="showSignUp()">Don’t have an account? Sign Up</a>
        </div>
    </div>

    <div class="form-container" id="signup-form" style="display: none;">
        <h2>Sign Up</h2>
        <p>Create your account</p>
        <form action="signup.php" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Sign Up</button>
        </form>
        <div class="alternate">
            <a href="#" onclick="showLogin()">Already have an account? Login</a>
        </div>
    </div>

    <script>
        function showSignUp() {
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('signup-form').style.display = 'block';
        }

        function showLogin() {
            document.getElementById('signup-form').style.display = 'none';
            document.getElementById('login-form').style.display = 'block';
        }
    </script>
</body>
</html>