<?php
session_start(); // Start the session

// Database connection
require 'db.php'; // Include the database connection

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login if the user is not logged in
    exit();
}

// Handle form submissions for adding, editing, and deleting records
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        // Handle adding a new record
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $age = intval(trim($_POST['age']));
        $address = trim($_POST['address']);
        $birthday = trim($_POST['birthday']);
        
        if (!empty($firstname) && !empty($lastname) && $age > 0 && !empty($address) && !empty($birthday)) {
            // Insert the new record into the database
            $stmt = $pdo->prepare("INSERT INTO users (firstname, lastname, age, address, birthday) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$firstname, $lastname, $age, $address, $birthday]);
        }
    } elseif (isset($_POST['edit'])) {
        // Handle editing an existing record
        $id = intval($_POST['id']);
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $age = intval(trim($_POST['age']));
        $address = trim($_POST['address']);
        $birthday = trim($_POST['birthday']);
        
        if (!empty($firstname) && !empty($lastname) && $age > 0 && !empty($address) && !empty($birthday)) {
            // Update the record in the database
            $stmt = $pdo->prepare("UPDATE users SET firstname = ?, lastname = ?, age = ?, address = ?, birthday = ? WHERE id = ?");
            $stmt->execute([$firstname, $lastname, $age, $address, $birthday, $id]);
        }
    } elseif (isset($_POST['delete'])) {
        // Handle deleting a record
        $id = intval($_POST['id']);
        // Delete the record from the database
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
    }
}

// Fetch all records from the database
$stmt = $pdo->query("SELECT * FROM users");
$records = $stmt->fetchAll();

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; }
        header { background-color: #000957; color: white; width: 100%; padding: 20px; text-align: center; }
        .container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); width: 80%; max-width: 600px; text-align: center; }
        .container h1 { color: #000957; }
        .item-list, .archive-list { margin-top: 20px; text-align: left; }
        .btn-actions { padding: 10px; background-color: #000957; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn-actions:hover { background-color: #0056b3; }
    </style>
</head>
<body>

<header>
    <h1>Welcome to the Homepage</h1>
</header>

<div class="container">
    <h1>Hello, <?php echo htmlspecialchars($username); ?>!</h1>
    <form method="POST">
        <input type="text" name="firstname" placeholder="First Name" required>
        <input type="text" name="lastname" placeholder="Last Name" required>
        <input type="number" name="age" placeholder="Age" required min="1">
        <input type="text" name="address" placeholder="Address" required>
        <input type="date" name="birthday" placeholder="Birthday" required>
        <button type="submit" name="add" class="btn-actions">Add Record</button>
    </form>

    <div class="item-list">
        <h2>Your Records</h2>
        <?php foreach ($records as $record): ?>
            <div>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($record['id']); ?>">
                    <input type="text" name="firstname" value="<?php echo htmlspecialchars($record['firstname']); ?>" required>
                    <input type="text" name="lastname" value="<?php echo htmlspecialchars($record['lastname']); ?>" required>
                    <input type="number" name="age" value="<?php echo htmlspecialchars($record['age']); ?>" required min="1">
                    <input type="text" name="address" value="<?php echo htmlspecialchars($record['address']); ?>" required>
                    <input type="date" name="birthday" value="<?php echo htmlspecialchars($record['birthday']); ?>" required>
                    <button type="submit" name="edit" class="btn-actions">Edit</button>
                </form>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($record['id']); ?>">
                    <button type="submit" name="delete" class="btn-actions">Delete</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

    <form action="logout.php" method="POST" style="margin-top: 20px;">
        <button type="submit" class="btn-actions">Logout</button>
    </form>
</div>

</body>
</html>