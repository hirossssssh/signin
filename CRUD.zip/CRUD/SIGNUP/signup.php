<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $conn = new mysqli('localhost', 'root', '', 'user_system');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $stmt = $conn->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    $stmt->bind_param('sss', $username, $email, $password);

    if ($stmt->execute()) {
        $message = 'Sign-up successful!';
        $message_type = 'success';
    } else {
        $message = 'Error: ' . $stmt->error;
        $message_type = 'error';
    }   

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('2.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        header {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            color: #000957;
            padding: 10px 20px;
            width: 100%;
            box-sizing: border-box;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 10;
            border-bottom: 1px solid #ddd;
        }

        header .logo {s
            display: flex;
            align-items: center;
            margin-right: 10px;
        }

        header  .logo img {
        width: 120px; /* Adjust this value to make the logo larger */
        height: auto; /* Keeps the aspect ratio of the logo */
        margin-right: 15px; /* Space between the logo and the text */
    }
        .header-text {
        display: flex;
        flex-direction: column;
        align-items: center; /* Centers the text horizontally */
        text-align: center; /* Ensures multi-line text is also centered */
    }

    .header-text h1 {
        margin: 0;
        font-size: 24px;
        color: #000957; /* Blue color for the text */
    }

    .header-text h2 {
        margin: 5px 0 0; /* Adds a small margin between title and address */
        font-size: 16px;
        color: #555; /* Subtle color for the address */
    }

        .form-container {
            background: #FFEB00;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
            margin-top: 170px;
        }

        .form-container h2 {
            color: #000957;
            margin-bottom: 20px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        .form-container input {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container button {
            padding: 10px;
            background: #000957;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-container button:hover {
            background: #0056b3;
        }

        .form-container a {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            font-weight: bold;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<header>
    <div class="logo">
        <img src="logogogo.png" alt="Logo">
    </div>
    <div class="header-text">
        <h1>ST. JOHN PAUL II COLLEGE OF DAVAO</h1>
        <h2>Ecoland Drive, Matina, Davao City</h2>
    </div>
</header>
<body>
    <div class="form-container">
        <h2>Sign Up</h2>
        <?php if (isset($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Sign Up</button>
        </form>
        <div class="alternate">
    <a href="login.php">Already have an account? Login</a>
</div>
    </div>
</body>
</html>