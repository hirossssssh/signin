<?php
session_start(); // Start the session

// Database connection
require 'db.php'; // Include the database connection

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Get logged-in user's account
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$_SESSION['username']]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found.";
    exit();
}

$user_id = $user['id'];

// Fetch deleted records with updated_at field for the archive page
$stmt = $pdo->prepare("SELECT id, firstname, lastname, age, address, birthday, COALESCE(updated_at, created_at) AS updated_at 
                       FROM archive 
                       WHERE user_id = ? AND status = 'deleted' 
                       ORDER BY updated_at DESC");
$stmt->execute([$user_id]);
$deleted_records = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archive</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; }
        .container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #000957; color: white; }
        a { text-decoration: none; color: #000957; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h1>Deleted Records (Archive)</h1>
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Age</th>
            <th>Address</th>
            <th>Birthday</th>
            <th>Deleted At</th>
        </tr>
        <?php foreach ($deleted_records as $record): ?>
            <tr>
                <td><?php echo htmlspecialchars($record['firstname']); ?></td>
                <td><?php echo htmlspecialchars($record['lastname']); ?></td>
                <td><?php echo htmlspecialchars($record['age']); ?></td>
                <td><?php echo htmlspecialchars($record['address']); ?></td>
                <td><?php echo htmlspecialchars($record['birthday']); ?></td>
                <td><?php echo isset($record['updated_at']) ? htmlspecialchars($record['updated_at']) : 'No update info'; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="homepage.php">Back to Homepage</a>
</div>
</body>
</html>
