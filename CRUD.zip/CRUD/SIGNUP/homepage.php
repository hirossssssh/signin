<?php
session_start(); // Start the session

// Database connection
require 'db.php'; // Include the database connection

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Get logged-in user's account
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$_SESSION['username']]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found.";
    exit();
}

$user_id = $user['id'];

// Handle form submissions for adding, editing, and soft-deleting records
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        // Add a new record to the archive
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $age = intval(trim($_POST['age']));
        $address = trim($_POST['address']);
        $birthday = date('Y-m-d', strtotime(trim($_POST['birthday'])));

        if (!empty($firstname) && !empty($lastname) && $age > 0 && !empty($address) && !empty($birthday)) {
            $stmt = $pdo->prepare("INSERT INTO archive (user_id, firstname, lastname, age, address, birthday, status) 
                                   VALUES (?, ?, ?, ?, ?, ?, 'active')");
            $stmt->execute([$user_id, $firstname, $lastname, $age, $address, $birthday]);
        }
    } elseif (isset($_POST['edit'])) {
        // Edit an existing record
        $id = intval($_POST['id']);
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $age = intval(trim($_POST['age']));
        $address = trim($_POST['address']);
        $birthday = date('Y-m-d', strtotime(trim($_POST['birthday'])));

        if (!empty($firstname) && !empty($lastname) && $age > 0 && !empty($address) && !empty($birthday)) {
            $stmt = $pdo->prepare("UPDATE archive 
                                   SET firstname = ?, lastname = ?, age = ?, address = ?, birthday = ? 
                                   WHERE id = ? AND user_id = ?");
            $stmt->execute([$firstname, $lastname, $age, $address, $birthday, $id, $user_id]);
        }
    } elseif (isset($_POST['delete'])) {
        // Soft delete a record (hide from homepage without removing from database)
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("UPDATE archive SET status = 'deleted' WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user_id]);
    }
}

// Fetch all active records from the archive for the logged-in user
$stmt = $pdo->prepare("SELECT * FROM archive WHERE user_id = ? AND status = 'active' ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$records = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Homepage</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; }
        header { background-color: #000957; color: white; padding: 20px; text-align: center; }
        .container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); width: 80%; max-width: 600px; margin: 20px auto; }
        .container h1 { color: #000957; }
        .item-list { margin-top: 20px; text-align: left; }
        .btn-actions { padding: 10px; background-color: #000957; color: white; border: none; border-radius: 5px; cursor: pointer; margin-right: 5px; }
        .btn-actions:hover { background-color: #0056b3; }
        input { padding: 8px; margin: 5px; width: calc(100% - 20px); border-radius: 5px; border: 1px solid #ccc; }
        form { margin-bottom: 10px; }
        .record-item { border-bottom: 1px solid #ddd; padding: 10px 0; }
    </style>
</head>
<body>

<header>
    <h1>User Homepage</h1>
</header>

<div class="container">
    <h1>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>

    <!-- Add Record Form -->
    <form method="POST">
        <input type="text" name="firstname" placeholder="First Name" required>
        <input type="text" name="lastname" placeholder="Last Name" required>
        <input type="number" name="age" placeholder="Age" required min="1">
        <input type="text" name="address" placeholder="Address" required>
        <input type="date" name="birthday" placeholder="Birthday" required>
        <button type="submit" name="add" class="btn-actions">Add Record</button>
    </form>

    <!-- Display User Records -->
    <div class="item-list">
        <h2>Your Records</h2>
        <?php if (!empty($records)): ?>
            <?php foreach ($records as $record): ?>
                <div class="record-item">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($record['id']); ?>">
                        <input type="text" name="firstname" value="<?php echo htmlspecialchars($record['firstname']); ?>" required>
                        <input type="text" name="lastname" value="<?php echo htmlspecialchars($record['lastname']); ?>" required>
                        <input type="number" name="age" value="<?php echo htmlspecialchars($record['age']); ?>" required min="1">
                        <input type="text" name="address" value="<?php echo htmlspecialchars($record['address']); ?>" required>
                        <input type="date" name="birthday" value="<?php echo htmlspecialchars($record['birthday']); ?>" required>
                        <button type="submit" name="edit" class="btn-actions">Edit</button>
                    </form>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($record['id']); ?>">
                        <button type="submit" name="delete" class="btn-actions">Remove</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No active records found.</p>
        <?php endif; ?>
    </div>
    <!-- Archive Button -->
<a href="archive.php" class="btn-actions" style="display: inline-block; margin-bottom: 20px;">View Archive</a>


    <!-- Logout Button -->
    <form action="logout.php" method="POST" style="margin-top: 20px;">
        <button type="submit" class="btn-actions">Logout</button>
    </form>
</div>

</body>
</html>