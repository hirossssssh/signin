-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2025 at 04:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `archive`
--

CREATE TABLE `archive` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `age` int(11) DEFAULT NULL CHECK (`age` > 0),
  `address` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','deleted') DEFAULT 'active',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archive`
--

INSERT INTO `archive` (`id`, `user_id`, `firstname`, `lastname`, `age`, `address`, `birthday`, `created_at`, `status`, `updated_at`) VALUES
(2, 1, 'rtret', 'dfgdfg', 23, 'sdfgsdrfgsd', '2023-09-14', '2025-02-16 15:21:05', 'deleted', '2025-02-16 23:33:47'),
(3, 1, 'rtret', 'dfgdfg', 23, 'sdfgsdrfgsd', '2023-09-14', '2025-02-16 15:23:17', 'deleted', '2025-02-16 23:33:47'),
(4, 1, 'gfdf', 'fghfgh', 22, 'sdfgdfsg', '2024-06-07', '2025-02-16 15:24:10', 'deleted', '2025-02-16 23:33:47'),
(5, 2, 'sdfdsf', 'fsdfsd', 22, 'fasdfas', '2024-06-06', '2025-02-16 15:26:11', 'deleted', '2025-02-16 23:33:47'),
(6, 2, 'sdfdsf', 'fsdfsd', 22, 'fasdfas', '2024-06-06', '2025-02-16 15:30:18', 'deleted', '2025-02-16 23:33:47'),
(7, 2, 'gfhfh', 'hfghgfh', 22, 'frtsdfsdf', '2024-09-19', '2025-02-16 15:31:13', 'deleted', '2025-02-16 23:35:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'shane', '$2y$10$AwdMURHPCdnqCeWi5ltG3OXMAzHygV9i8UPV8CLxJZ8tmvHo47TUq', 'shanenatra225@gmail.'),
(2, 'hiroshi', '$2y$10$6YIixOYGV2f5iOw8p4p7sexFN9K0Xd.QXkQlX7cOgWDEf7DbrsovC', 'makabenta123@gmail.c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archive`
--
ALTER TABLE `archive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `archive`
--
ALTER TABLE `archive`
  ADD CONSTRAINT `archive_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
